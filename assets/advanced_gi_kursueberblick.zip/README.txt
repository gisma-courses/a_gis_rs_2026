Quellmaterialien des Kurses. Für Website-Build und Datenpakete das vollständige Repository verwenden.
